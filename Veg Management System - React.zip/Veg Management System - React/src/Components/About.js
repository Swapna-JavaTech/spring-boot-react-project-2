


function About(props){

    return(
    
        <div className="body-content">
            <h4><b>About Us:</b></h4>
            <h5>
                We are online Vegetable shopping organisation with thousands of vegetable 
                products delivered by hundreds of vendors 
            </h5>    
        </div>

    );

}

export default About